#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Funkcja do reorganizacji tablicy
void reorganize(int arr[], int n) {
    int *result = (int *)malloc(n * sizeof(int));  // Tworzymy dynamiczną tablicę na wynik
    int index = 0;  // Licznik elementów w tablicy wynikowej

    for (int i = 0; i < n; i++) {
        // Sprawdzamy, czy bieżący element został już przetworzony
        int alreadyProcessed = 0;
        for (int k = 0; k < index; k++) {
            if (result[k] == arr[i]) {  // Jeżeli znaleziono element w tablicy wynikowej
                alreadyProcessed = 1;  // Ustawiamy flagę
                break;  // Nie musimy dalej szukać
            }
        }

        // Jeśli element nie był jeszcze przetworzony, dodajemy wszystkie jego wystąpienia
        if (!alreadyProcessed) {
            for (int j = 0; j < n; j++) {
                if (arr[j] == arr[i]) {  // Jeżeli element pasuje
                    result[index++] = arr[j];  // Dodajemy go do tablicy wynikowej
                }
            }
        }
    }

    // Przepisanie zawartości tablicy wynikowej do oryginalnej tablicy
    for (int i = 0; i < index; i++) {
        arr[i] = result[i];  // Kopiujemy wynik do oryginalnej tablicy
    }

    free(result);  // Zwalniamy pamięć dynamiczną, ponieważ jest już niepotrzebna
}

// Uproszczona wersja funkcji reorganize
void reorganize2(int arr[], int n) {
    int *result = (int *)malloc(n * sizeof(int));  // Tworzymy dynamiczną tablicę na wynik
    int index = 0;  // Indeks do zapisywania elementów w tablicy wynikowej

    // Przechodzimy po wszystkich elementach tablicy
    for (int i = 0; i < n; i++) {
        // Szukamy wszystkich wystąpień bieżącego elementu (arr[i]) w tablicy arr
        for (int j = 0; j < n; j++) {
            if (arr[j] == arr[i]) result[index++] = arr[j];  // Jeśli znaleziono, zapisujemy do tablicy wynikowej
        }

        // Pomiń kolejne identyczne elementy, aby nie dodawać ich ponownie
        while (i + 1 < n && arr[i] == arr[i + 1]) i++;  // Jeśli arr[i] jest równy arr[i+1], pomijamy ten element
    }

    // Przepisujemy wynik z tablicy result do oryginalnej tablicy arr
    for (int i = 0; i < index; i++) {
        arr[i] = result[i];  // Kopiujemy wynik do oryginalnej tablicy
    }

    free(result);  // Zwalniamy pamięć dynamiczną, bo już nie jest potrzebna
}

// Funkcja do drukowania tablicy
void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);  // Wyświetlamy każdy element
    }
    printf("\n");  // Dodajemy nową linię na końcu
}

void random(int *tab, int n, int nmax) {
    // Pętla iterująca przez każdy element tablicy 'tab'
    for (int i = 0; i < n; i++) {
        // Wypełnia tablicę liczbami losowymi z zakresu 0 do nmax-1
        tab[i] = rand() % nmax;  // rand() generuje losową liczbę całkowitą, a % nmax ogranicza ją do przedziału [0, nmax-1]
    }
}

int *tab ;  // Wskaźnik na tablicę liczb całkowitych
float *times1 ; // Wskaźniki na tablice liczb typu float do przechowywania wyników
float *times2 ;
clock_t begin ; // Zmienne przechowujące odpowiednio czas początkowy i końcowy
clock_t end ;

// Funkcja główna - punkt startowy programu
int main() {
    int arr[100], n = 0, num;

    // Otwieramy plik do zapisu wyników w trybie dopisywania
    FILE *file = fopen("wynik.txt", "a");
    if (file == NULL) {
        printf("Blad: nie mozna utworzyc pliku wynik.txt\n");
        return 1;  // Zakończ program w przypadku błędu otwarcia pliku
    }

    // Wprowadzenie danych od użytkownika
    printf("Wprowadz liczby (wprowadzenie liczby wiekszej niz 1000 zakonczy wprowadzanie):\n");
    fprintf(file, "Tablica wejsciowa:\n");  // Zapisujemy nagłówek do pliku
    while (1) {
        printf("Liczba %d: ", n + 1);
        scanf("%d", &num);  // Odczytujemy liczbę od użytkownika
        if (num > 1000) break;  // Kończymy wprowadzanie, jeśli liczba jest większa niż 1000
        arr[n++] = num;  // Dodajemy liczbę do tablicy
        fprintf(file, "%d ", num);  // Zapisujemy liczbę do pliku
    }
    fprintf(file, "\n");  // Dodajemy nową linię w pliku

    // Wywołanie funkcji reorganizującej 1
    reorganize(arr, n);

    // Wyświetlenie tablicy wyjściowej w konsoli i zapisanie jej do pliku
    printf("Tablica wyjsciowa z reorganize:\n");
    fprintf(file, "Tablica wyjsciowa z reorganize:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);  // Wyświetlamy każdy element
        fprintf(file, "%d ", arr[i]);  // Zapisujemy wynik do pliku
    }
    printf("\n");  // Nowa linia w konsoli
    fprintf(file, "\n");  // Nowa linia w pliku

    // Wywołanie funkcji reorganizującej 2
    reorganize2(arr, n);

    // Wyświetlenie tablicy wyjściowej w konsoli i zapisanie jej do pliku
    printf("Tablica wyjsciowa z reorganize2:\n");
    fprintf(file, "Tablica wyjsciowa z reorganize2:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);  // Wyświetlamy każdy element
        fprintf(file, "%d ", arr[i]);  // Zapisujemy wynik do pliku
    }
    printf("\n");  // Nowa linia w konsoli
    fprintf(file, "\n");  // Nowa linia w pliku

    // Sekcja z przykładami
    // Predefiniowane przykłady działania programu
    printf("\n--- Przyklady ---\n");
    int example1[] = {1, 2, 3, 1, 2, 1};  // Pierwszy przykład wejściowy
    int example2[] = {5, 4, 5, 5, 3, 1, 2, 2, 4};  // Drugi przykład wejściowy

    printf("Przyklad 1: Wejscie: ");
    printArray(example1, 6);  // Wyświetlenie wejściowej tablicy dla przykładu 1
    reorganize(example1, 6);  // Przetwarzamy tablicę
    printf("Wyjscie z reorganize: ");
    printArray(example1, 6);  // Wyświetlenie wyniku dla przykładu 1

    printf("Przyklad 1: Wejscie z reorganize2: ");
    printArray(example1, 6);  // Wyświetlenie wejściowej tablicy dla przykładu 1
    reorganize2(example1, 6);  // Przetwarzamy tablicę
    printf("Wyjscie z reorganize2: ");
    printArray(example1, 6);  // Wyświetlenie wyniku dla przykładu 1

    printf("Przyklad 2: Wejscie: ");
    printArray(example2, 9);  // Wyświetlenie wejściowej tablicy dla przykładu 2
    reorganize(example2, 9);  // Przetwarzamy tablicę
    printf("Wyjscie z reorganize: ");
    printArray(example2, 9);  // Wyświetlenie wyniku dla przykładu 2

    printf("Przyklad 2: Wejscie z reorganize2: ");
    printArray(example2, 9);  // Wyświetlenie wejściowej tablicy dla przykładu 2
    reorganize2(example2, 9);  // Przetwarzamy tablicę
    printf("Wyjscie z reorganize2: ");
    printArray(example2, 9);  // Wyświetlenie wyniku dla przykładu 2

    // Zamykamy plik, ponieważ zakończyliśmy zapisywanie danych
    fclose(file);

    printf("Wyniki zostaly zapisane do pliku wynik.txt\n");

    // Tablica zawierająca różne rozmiary danych do testów
    int N[] = {2500, 5000, 10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000};

    // Obliczamy liczbę testów na podstawie rozmiaru tablicy N
    int tests_num = sizeof(N) / sizeof(N[0]);

    // Alokujemy pamięć na przechowywanie czasów wykonania dwóch funkcji (times1 i times2)
    times1 = (float *) malloc(tests_num * sizeof (float));
    times2 = (float *) malloc(tests_num * sizeof (float));

    // Pętla do przeprowadzenia każdego testu
    for(int i = 0; i < tests_num; i++) {
    // Alokujemy pamięć dla tablicy o rozmiarze N[i] dla bieżącego testu
    tab = (int *) malloc(N[i] * sizeof (int));

    // Wypełniamy tablicę 'tab' losowymi wartościami w przedziale 0-1000
    random(tab, N[i], 1000);

    // Zapisujemy czas początkowy dla pierwszej funkcji (reorganize)
    begin = clock();

    // Wywołujemy pierwszą funkcję, która reorganizuje dane w 'tab'
    reorganize(tab, N[i]);

    // Zapisujemy czas końcowy dla pierwszej funkcji
    end = clock();

    // Obliczamy czas wykonania pierwszej funkcji i zapisujemy go w tablicy times1
    times1[i] = (double)(end - begin) / CLOCKS_PER_SEC;

    // Zapisujemy czas początkowy dla drugiej funkcji (reorganize2)
    begin = clock();

    // Wywołujemy drugą funkcję, która reorganizuje dane w 'tab'
    reorganize2(tab, N[i]);

    // Zapisujemy czas końcowy dla drugiej funkcji
    end = clock();

    // Obliczamy czas wykonania drugiej funkcji i zapisujemy go w tablicy times2
    times2[i] = (double)(end - begin) / CLOCKS_PER_SEC;

    // Zwalniamy pamięć przydzieloną dla tablicy 'tab' po każdym teście
    free(tab);
}

    // Wypisujemy nową linię przed tabelą wyników
    printf("\n");

    // Wypisujemy nagłówek tabeli wyników
    printf(" L.p. n t1 [s] t2 [s] \n ");

    // Pętla do wypisania wyników: numer testu, rozmiar tablicy i czasy dla obu funkcji
    for(int i = 0; i < tests_num; i++) {
    printf("%2d %10d %6.6f %6.6f\n ", i + 1, N[i], times1[i], times2[i]);
    }

    return 0;  // Zakończenie programu
}
